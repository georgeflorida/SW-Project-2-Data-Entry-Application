class GroceryDbEntry:
    def __init__(self, item='Fresh Produce', allergen ='None', name ='product', quantity=1, price=1):
        self.item = item
        self.allergen=allergen
        self.name = name
        self.quantity = quantity
        self.price = price